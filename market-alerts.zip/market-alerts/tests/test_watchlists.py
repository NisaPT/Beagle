import json, threading, urllib.error, urllib.request
import pytest
from marketalerts.store import Store
from marketalerts.web import serve


@pytest.fixture
def store(tmp_path):
    return Store(str(tmp_path / "w.db"))


def test_store_watchlist_lifecycle(store):
    wid = store.create_watchlist("Core ETFs")
    assert store.add_symbol(wid, " spy ") == "SPY"
    store.add_symbol(wid, "SPY")  # duplicado ignorado
    store.add_symbol(wid, "btc-usd")
    assert store.list_watchlists() == [{"id": wid, "name": "Core ETFs", "symbols": ["BTC-USD", "SPY"]}]
    assert store.all_symbols() == ["BTC-USD", "SPY"]
    assert store.remove_symbol(wid, "spy") and not store.remove_symbol(wid, "spy")
    assert store.delete_watchlist(wid)
    assert store.all_symbols() == [] and store.list_watchlists() == []

def test_delete_cascades_symbols(store):
    wid = store.create_watchlist("A"); store.add_symbol(wid, "AAPL")
    store.delete_watchlist(wid)
    assert store.db.execute("SELECT COUNT(*) FROM watchlist_symbols").fetchone()[0] == 0

@pytest.mark.parametrize("bad", ["", "  ", "A B", "AAPL;DROP", "x" * 30, "<script>"])
def test_invalid_symbols_rejected(store, bad):
    wid = store.create_watchlist("A")
    with pytest.raises(ValueError):
        store.add_symbol(wid, bad)

def test_duplicate_or_empty_name(store):
    store.create_watchlist("A")
    with pytest.raises(ValueError): store.create_watchlist("A")
    with pytest.raises(ValueError): store.create_watchlist(" ")

def test_all_symbols_dedup_across_lists(store):
    a, b = store.create_watchlist("A"), store.create_watchlist("B")
    store.add_symbol(a, "AAPL"); store.add_symbol(b, "AAPL")
    assert store.all_symbols() == ["AAPL"]


@pytest.fixture
def server(store):
    srv = serve(store, 0)
    t = threading.Thread(target=srv.serve_forever, daemon=True); t.start()
    yield f"http://127.0.0.1:{srv.server_address[1]}", store
    srv.shutdown()

def call(base, path, method="GET", body=None):
    req = urllib.request.Request(base + path, method=method,
        data=json.dumps(body).encode() if body is not None else None,
        headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read())

def test_http_flow(server):
    base, store = server
    code, out = call(base, "/api/watchlists", "POST", {"name": "Swing"}); assert code == 201
    wid = out["id"]
    assert call(base, f"/api/watchlists/{wid}/symbols", "POST", {"symbol": "qqq"})[0] == 201
    assert call(base, "/api/watchlists")[1] == [{"id": wid, "name": "Swing", "symbols": ["QQQ"]}]
    assert store.all_symbols() == ["QQQ"]  # o scanner vê o que a UI criou
    assert call(base, f"/api/watchlists/{wid}/symbols/QQQ", "DELETE")[0] == 200
    assert call(base, f"/api/watchlists/{wid}", "DELETE")[0] == 200

def test_http_errors(server):
    base, _ = server
    assert call(base, "/api/watchlists", "POST", {"name": ""})[0] == 400
    assert call(base, "/api/watchlists/99/symbols", "POST", {"symbol": "AAPL"})[0] == 404
    assert call(base, "/api/watchlists/99", "DELETE")[0] == 404
    assert call(base, "/nada")[0] == 404

def test_http_bad_json(server):
    base, _ = server
    req = urllib.request.Request(base + "/api/watchlists", method="POST", data=b"{x")
    with pytest.raises(urllib.error.HTTPError) as e: urllib.request.urlopen(req)
    assert e.value.code == 400

def test_index_served(server):
    base, _ = server
    with urllib.request.urlopen(base + "/") as r:
        assert r.status == 200 and b"Criar lista" in r.read()
