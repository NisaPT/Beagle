from datetime import datetime, timedelta
import pytest
from marketalerts.models import Bar, Opportunity
from marketalerts.monitor import check_positions, stop_target_signal
from marketalerts.providers import FinnhubProvider, MarketauxNews, NewsRouter, TwelveDataProvider
from marketalerts.rules import RuleConfig, evaluate
from marketalerts.scanner import run_once
from marketalerts.store import Store
from marketalerts.valuation import valuation
from tests.test_all import mk
from tests.test_workflow import Prov, Sink, held, st  # noqa: F401


# ---------------------------------------------------------------- valorização
def long_series(shape):
    """~260 dias: base oscilante; 'shape' decide onde o preço final fica no intervalo de 52s."""
    c = [100 + (i % 2) * 0.5 for i in range(200)]
    c += [100 + i * (50 / 59) for i in range(60)] if shape == "up" else [100 - i * (30 / 59) for i in range(60)]
    return mk(c, spread=0.5)

def test_valuation_expensive_near_52w_high():
    v = valuation(long_series("up"))
    assert v["label"] == "caro" and v["pos52"] > 0.9 and v["vs200_pct"] > 0

def test_valuation_cheap_near_52w_low():
    v = valuation(long_series("down"))
    assert v["label"] == "barato" and v["pos52"] < 0.1 and "52 semanas" in v["text"]

def test_valuation_needs_history():
    assert valuation(mk([100.0] * 50)) is None

def dip_on(base_pos):
    """Série longa terminando numa queda forte; base_pos 'low' (barato) ou 'high' (caro)."""
    if base_pos == "high":   # subiu muito no ano e agora cai
        c = [100 + i * 1.0 for i in range(240)]
    else:                    # já estava no fundo do intervalo
        c = [200 - i * 0.4 for i in range(240)]
    last = c[-1]
    c += [last * f for f in (0.99, 0.97, 0.94, 0.91, 0.88)]
    return mk(c, spread=0.5)

def test_cheap_adds_point_expensive_removes_and_text_present():
    cheap = evaluate("T", dip_on("low"), 0)
    dear = evaluate("T", dip_on("high"), 0, RuleConfig(min_score=0))
    assert cheap and dear
    assert "barato" in cheap.valuation and "caro" in dear.valuation
    assert cheap.metrics["score"] == cheap.score and cheap.score > dear.score

def test_expensive_dip_can_fall_below_min_score():
    assert evaluate("T", dip_on("high"), 0, RuleConfig(min_score=7)) is None

def test_stretch_on_expensive_mentions_price():
    c = [100 + i * 0.3 for i in range(240)] + [175, 180, 185, 190, 200]
    o = evaluate("T", mk(c, spread=0.5), 0)
    assert o and o.kind == "SELL_STRETCH" and "caro" in o.reason


# ---------------------------------------------------------------- notícias preguiçosas
def test_news_only_queried_when_price_triggers(st):
    calls = []
    class News:
        def news_count(self, s, h): calls.append(s); return 0
    quiet = mk([100 + (i % 2) * 0.5 for i in range(60)])
    from tests.test_all import dip_series
    run_once(["QUIET"], Prov(quiet), Sink(), st, news=News(), now=1)
    assert calls == []
    run_once(["DIP"], Prov(dip_series()), Sink(), st, news=News(), now=1)
    assert calls == ["DIP"]

def test_news_failure_means_unknown_not_zero(st):
    from tests.test_all import dip_series
    class Bad:
        def news_count(self, s, h): raise RuntimeError("quota")
    assert run_once(["X"], Prov(dip_series()), Sink(), st, news=Bad(), now=1) == []


# ---------------------------------------------------------------- Finnhub / Marketaux / router
NOW = 1_800_000_000.0

def test_finnhub_quote_and_header_auth():
    seen = {}
    def get(url, h): seen.update(url=url, h=h); return {"c": 123.4, "h": 125, "l": 120, "o": 121, "pc": 119, "t": 1}
    p = FinnhubProvider("SEGREDO", http_get=get, sleep=lambda s: None)
    assert p.get_quote("AAPL") == 123.4
    assert "symbol=AAPL" in seen["url"] and "SEGREDO" not in seen["url"] and seen["h"]["X-Finnhub-Token"] == "SEGREDO"

def test_finnhub_zero_quote_is_error():
    p = FinnhubProvider("K", http_get=lambda u, h: {"c": 0, "d": None, "t": 0}, sleep=lambda s: None)
    with pytest.raises(RuntimeError): p.get_quote("NOPE")

def test_finnhub_news_counts_only_recent():
    items = [{"datetime": NOW - 3600}, {"datetime": NOW - 47 * 3600}, {"datetime": NOW - 100 * 3600}]
    p = FinnhubProvider("K", http_get=lambda u, h: items, sleep=lambda s: None, now=lambda: NOW)
    assert p.news_count("AAPL", 48) == 2

def test_finnhub_error_payload():
    p = FinnhubProvider("K", http_get=lambda u, h: {"error": "API limit reached"}, sleep=lambda s: None)
    with pytest.raises(RuntimeError, match="limit"): p.news_count("AAPL")

def test_finnhub_throttle_default_spacing():
    t = [0.0]; sl = []
    p = FinnhubProvider("K", calls_per_minute=50, http_get=lambda u, h: {"c": 1.0}, sleep=lambda s: (sl.append(s), t.__setitem__(0, t[0] + s)), clock=lambda: t[0])
    p.get_quote("A"); p.get_quote("B")
    assert sl == [pytest.approx(1.2)]

def test_marketaux_counts_and_hides_token():
    seen = {}
    def get(url, h): seen["url"] = url; return {"meta": {"found": 4, "returned": 3}, "data": [{}, {}, {}]}
    assert MarketauxNews("TOK", http_get=get, now=lambda: NOW).news_count("VWCE.DE", 48) == 4
    assert "symbols=VWCE.DE" in seen["url"] and "published_after" in seen["url"]
    bad = MarketauxNews("TOK", http_get=lambda u, h: {"error": {"code": "usage_limit_reached", "message": "limite"}})
    with pytest.raises(RuntimeError) as e: bad.news_count("X")
    assert "TOK" not in str(e.value)

def test_news_router_by_suffix():
    class S:
        def __init__(self, n): self.n = n
        def news_count(self, s, h): return self.n
    r = NewsRouter(us=S(1), intl=S(2))
    assert r.news_count("AAPL") == 1 and r.news_count("VWCE.DE") == 2
    assert NewsRouter(us=S(1)).news_count("VWCE.DE") is None   # sem fonte -> desconhecido, nunca 0

def test_twelvedata_quote():
    p = TwelveDataProvider("K", http_get=lambda u, h: {"price": "172.58"}, sleep=lambda s: None)
    assert p.get_quote("AAPL") == 172.58
    bad = TwelveDataProvider("K", http_get=lambda u, h: {"code": 400, "message": "symbol invalid", "status": "error"}, sleep=lambda s: None)
    with pytest.raises(RuntimeError): bad.get_quote("ZZZ")


# ---------------------------------------------------------------- monitor em tempo quase real
def test_stop_signal_uses_live_price_not_close(st):
    pid = held(st, stop=95.0, target=110.0)
    sink = Sink()
    # o fecho diário ainda está em 100 (acima do stop), mas o preço atual já está abaixo
    assert check_positions(st, lambda s: 100.0, sink, now=10) == []
    out = check_positions(st, lambda s: 94.5, sink, now=20)
    assert [o.kind for o in out] == ["STOP_HIT"] and len(sink.sent) == 1
    p = st.open_positions()[0]
    assert p["status"] == "sell_signal" and p["sell_ts"] == 20 and p["last_price"] == 94.5
    assert check_positions(st, lambda s: 90.0, sink, now=30) == []     # sem repetição

def test_monitor_target_and_quiet_updates_price(st):
    held(st, stop=95.0, target=110.0)
    assert check_positions(st, lambda s: 102.0, Sink(), now=5) == []
    assert st.open_positions()[0]["last_price"] == 102.0
    assert [o.kind for o in check_positions(st, lambda s: 110.5, Sink(), now=6)] == ["TARGET_HIT"]

def test_monitor_survives_quote_errors_and_push_failures(st):
    held(st, stop=95.0, target=110.0)
    def boom(s): raise RuntimeError("sem rede")
    assert check_positions(st, boom, Sink(), now=1) == []
    s = Sink(); s.fail = True
    assert check_positions(st, lambda x: 90.0, s, now=2) == []
    assert st.open_positions()[0]["status"] == "open"                  # tenta de novo
    s.fail = False
    assert len(check_positions(st, lambda x: 90.0, s, now=3)) == 1

def test_monitor_ignores_flagged_and_closed(st):
    pid = held(st, stop=95.0, target=110.0)
    check_positions(st, lambda s: 90.0, Sink(), now=1)
    calls = []
    check_positions(st, lambda s: calls.append(s) or 90.0, Sink(), now=2)
    assert calls == []                                                   # já sinalizada: não consulta preço

def test_stop_target_signal_pure():
    pos = {"entry": 100.0, "stop": 95.0, "target": 110.0}
    assert stop_target_signal(pos, 100.0) is None
    assert stop_target_signal(pos, 95.0)[0] == "STOP_HIT"
    assert stop_target_signal(pos, 110.0)[0] == "TARGET_HIT"


# ---------------------------------------------------------------- notícias: catalisadores, ETFs, erros HTTP
from marketalerts.providers import has_catalyst, _http_get_json
import io, json as _json, urllib.error as _ue, urllib.request as _ur

def test_has_catalyst_examples():
    assert has_catalyst("Apple misses earnings estimates, shares fall")
    assert has_catalyst("Analyst downgrades Tesla")
    assert has_catalyst("SEC opens investigation into company")
    assert not has_catalyst("Why Apple stock is moving today")
    assert not has_catalyst("5 tech stocks to watch this week")

def fh_items(heads):
    return [{"datetime": NOW - 3600, "headline": h, "summary": ""} for h in heads]

def test_finnhub_catalyst_count_ignores_noise():
    heads = ["Why AAPL stock is moving", "Top stocks to watch", "Apple faces new antitrust lawsuit"]
    p = FinnhubProvider("K", http_get=lambda u, h: fh_items(heads), sleep=lambda s: None, now=lambda: NOW)
    assert p.news_count("AAPL") == 3 and p.catalyst_count("AAPL") == 1
    assert p.headlines("AAPL", 48, 2) == heads[:2]

def test_finnhub_item_without_text_counts_as_possible_reason():
    p = FinnhubProvider("K", http_get=lambda u, h: [{"datetime": NOW - 10}], sleep=lambda s: None, now=lambda: NOW)
    assert p.catalyst_count("AAPL") == 1

def test_marketaux_catalyst_and_headlines():
    data = {"meta": {"found": 9, "returned": 3}, "data": [{"title": "Fund inflows steady"}, {"title": "x"}, {"title": "y"}]}
    m = MarketauxNews("T", http_get=lambda u, h: data, now=lambda: NOW)
    assert m.headlines("VWCE.DE") == ["Fund inflows steady", "x", "y"]
    assert m.catalyst_count("VWCE.DE") == 1   # há mais artigos do que os devolvidos -> assume motivo

def test_scanner_catalyst_mode_ignores_generic_news(st):
    from tests.test_all import dip_series
    class N:
        def news_count(self, s, h): return 118
        def catalyst_count(self, s, h): return 0
    out = run_once(["X"], Prov(dip_series()), Sink(), st, news=N(), now=1)
    assert len(out) == 1                                              # 118 notícias genéricas não bloqueiam
    out2 = run_once(["Y"], Prov(dip_series()), Sink(), st, news=N(), now=2, news_mode="count")
    assert out2 == []                                                 # modo 'count': 118 notícias = há motivo

def test_catalyst_blocks_alert(st):
    from tests.test_all import dip_series
    class N:
        def news_count(self, s, h): return 5
        def catalyst_count(self, s, h): return 1
    assert run_once(["X"], Prov(dip_series()), Sink(), st, news=N(), now=1) == []

def test_etf_skips_company_news_and_is_flagged(st):
    from tests.test_all import dip_series
    class Boom:
        def news_count(self, s, h): raise AssertionError("não devia ser chamado para ETFs")
    out = run_once(["EEM"], Prov(dip_series()), Sink(), st, news=Boom(), now=1, etfs=["eem"])
    assert len(out) == 1 and "NÃO verificadas" in out[0].reason

def test_http_error_body_is_surfaced_without_secrets(monkeypatch):
    def fake_urlopen(req, timeout=0):
        raise _ue.HTTPError(req.full_url, 403, "Forbidden", {}, io.BytesIO(b'{"error":"You don\'t have access to this resource."}'))
    monkeypatch.setattr(_ur, "urlopen", fake_urlopen)
    with pytest.raises(RuntimeError) as e:
        _http_get_json("https://x.test/a?api_token=SEGREDO")
    assert "403" in str(e.value) and "access" in str(e.value) and "SEGREDO" not in str(e.value)

def test_http_error_plain_body(monkeypatch):
    def fake_urlopen(req, timeout=0):
        raise _ue.HTTPError(req.full_url, 404, "NF", {}, io.BytesIO(b"<html>nope</html>"))
    monkeypatch.setattr(_ur, "urlopen", fake_urlopen)
    with pytest.raises(RuntimeError, match="HTTP 404"):
        _http_get_json("https://x.test/")
