import json, threading, urllib.error, urllib.request
from datetime import datetime, timedelta
import pytest
from marketalerts.models import Bar
from marketalerts.notifier import NtfyNotifier, format_message
from marketalerts.rules import RuleConfig, evaluate
from marketalerts.scanner import run_once
from marketalerts.store import Store
from marketalerts.web import serve
from tests.test_all import dip_series, flat_noise, mk


class Prov:
    def __init__(self, bars, news=0): self.bars, self.news = bars, news
    def get_bars(self, s, d):
        if s == "BAD": raise RuntimeError("falha de rede")
        return self.bars[s] if isinstance(self.bars, dict) else self.bars
    def news_count(self, s, h): return self.news

class Sink:
    def __init__(self): self.sent, self.fail = [], False
    def send(self, o):
        if self.fail: raise RuntimeError("ntfy em baixo")
        self.sent.append(o)

@pytest.fixture
def st(tmp_path): return Store(str(tmp_path / "w.db"))


# ---- pontuação de qualidade
def test_score_present_and_threshold():
    o = evaluate("T", dip_series(), 0)
    assert o.max_score == 7 and o.score >= 4
    assert evaluate("T", dip_series(), 0, RuleConfig(min_score=7)) is None

def test_unverified_news_scores_lower():
    a = evaluate("T", dip_series(), 0).score
    b = evaluate("T", dip_series(), None, RuleConfig(allow_unverified_news=True)).score
    assert b == a - 1


# ---- ciclo de vida: alerta -> aplicar/rejeitar -> posição
def test_buy_alert_pending_then_push(st):
    sink = Sink()
    out = run_once(["X"], Prov(dip_series()), sink, st, now=1000)
    assert len(out) == 1 and len(sink.sent) == 1
    al = st.pending_alerts()
    assert len(al) == 1 and al[0]["symbol"] == "X" and al[0]["ts"] == 1000 and al[0]["stop"] < al[0]["price"]

def test_reject_makes_alert_disappear_and_cooldown_blocks_repeat(st):
    sink = Sink(); prov = Prov(dip_series())
    run_once(["X"], prov, sink, st, now=1000)
    st.reject_alert(st.pending_alerts()[0]["id"])
    assert st.pending_alerts() == []
    assert run_once(["X"], prov, sink, st, now=2000) == []         # cooldown 24h
    assert len(run_once(["X"], prov, sink, st, now=1000 + 25 * 3600)) == 1  # expirou

def test_no_duplicate_while_pending(st):
    sink = Sink(); prov = Prov(dip_series())
    run_once(["X"], prov, sink, st, now=1000)
    assert run_once(["X"], prov, sink, st, now=1000 + 30 * 3600) == []
    assert len(st.pending_alerts()) == 1

def test_apply_creates_monitored_position(st):
    run_once(["X"], Prov(dip_series()), Sink(), st, now=1000)
    a = st.pending_alerts()[0]
    pid = st.apply_alert(a["id"], now=1500)
    assert st.pending_alerts() == []
    pos = st.open_positions()[0]
    assert pos["id"] == pid and pos["symbol"] == "X" and pos["entry"] == a["price"]
    assert pos["stop"] == a["stop"] and pos["target"] == a["target"] and pos["status"] == "open"

def test_double_apply_and_reject_after_apply_fail(st):
    run_once(["X"], Prov(dip_series()), Sink(), st, now=1000)
    aid = st.pending_alerts()[0]["id"]
    st.apply_alert(aid)
    with pytest.raises(KeyError): st.apply_alert(aid)
    with pytest.raises(KeyError): st.reject_alert(aid)
    assert len(st.open_positions()) == 1

def test_held_symbol_gets_no_new_buy_alert(st):
    sink = Sink(); prov = Prov(dip_series())
    run_once(["X"], prov, sink, st, now=1000)
    st.apply_alert(st.pending_alerts()[0]["id"])
    n = len(sink.sent)
    run_once(["X"], prov, sink, st, now=1000 + 48 * 3600)
    assert st.pending_alerts() == []
    assert all(o.kind != "BUY_DIP" for o in sink.sent[n:])


# ---- sinais de venda para posições aplicadas
def held(st, price=100.0, stop=95.0, target=110.0, sym="X"):
    run_once([sym], Prov(dip_series()), Sink(), st, now=1)
    aid = st.pending_alerts()[0]["id"]
    pid = st.apply_alert(aid, now=2)
    st.db.execute("UPDATE positions SET entry=?, stop=?, target=? WHERE id=?", (price, stop, target, pid))
    st.db.commit()
    return pid

def bars_at(price): return mk(flat_noise(59) + [price])

def test_stop_hit_pushes_once_and_flags_position(st):
    pid = held(st)
    sink = Sink(); prov = Prov(bars_at(94.0))
    out = run_once([], prov, sink, st, now=5000)   # símbolo vem das posições
    assert [o.kind for o in out] == ["STOP_HIT"]
    p = st.open_positions()[0]
    assert p["status"] == "sell_signal" and p["sell_kind"] == "STOP_HIT" and p["sell_ts"] == 5000
    assert run_once([], prov, sink, st, now=6000) == []         # sem repetição
    assert len(sink.sent) == 1

def test_target_hit(st):
    held(st)
    out = run_once([], Prov(bars_at(111.0)), Sink(), st, now=5000)
    assert [o.kind for o in out] == ["TARGET_HIT"]

def test_overextended_triggers_sell_for_held_only(st):
    held(st, stop=50.0, target=500.0)
    c = flat_noise(55) + [102, 105, 109, 113, 118]
    out = run_once([], Prov(mk(c)), Sink(), st, now=5000)
    assert [o.kind for o in out] == ["SELL_STRETCH"]

def test_stretch_on_unheld_symbol_is_ignored(st):
    c = flat_noise(55) + [102, 105, 109, 113, 118]
    assert run_once(["Y"], Prov(mk(c)), Sink(), st, now=1) == []

def test_position_waits_quietly_and_price_updates(st):
    pid = held(st)
    assert run_once([], Prov(bars_at(101.0)), Sink(), st, now=7000) == []
    p = st.open_positions()[0]
    assert p["status"] == "open" and p["last_price"] == 101.0 and p["last_ts"] == 7000

def test_close_position_removes_it(st):
    pid = held(st)
    run_once([], Prov(bars_at(94.0)), Sink(), st, now=5000)
    st.close_position(pid)
    assert st.open_positions() == []
    with pytest.raises(KeyError): st.close_position(pid)

def test_sell_push_failure_retries_next_cycle(st):
    held(st)
    sink = Sink(); sink.fail = True
    assert run_once([], Prov(bars_at(94.0)), sink, st, now=5000) == []
    assert st.open_positions()[0]["status"] == "open"
    sink.fail = False
    assert len(run_once([], Prov(bars_at(94.0)), sink, st, now=5001)) == 1


# ---- push falhado do alerta de compra: visível na app e reenviado
def test_failed_buy_push_still_visible_and_retried_once(st):
    sink = Sink(); sink.fail = True
    run_once(["X"], Prov(dip_series()), sink, st, now=1000)
    assert len(st.pending_alerts()) == 1 and len(sink.sent) == 0
    sink.fail = False
    run_once(["X"], Prov(dip_series()), sink, st, now=1100)
    assert len(sink.sent) == 1 and len(st.pending_alerts()) == 1
    run_once(["X"], Prov(dip_series()), sink, st, now=1200)
    assert len(sink.sent) == 1                                     # não reenvia de novo

def test_bad_symbol_does_not_stop_others(st):
    out = run_once(["BAD", "OK"], Prov(dip_series()), Sink(), st, now=1)
    assert [o.symbol for o in out] == ["OK"]


# ---- mensagens push
def test_push_title_is_ascii_and_priorities():
    calls = []
    n = NtfyNotifier("t", post=lambda u, d, h: calls.append((d, h)) or 200)
    o = evaluate("AAPL", dip_series(), 0)
    n.send(o)
    body, h = calls[0]
    h["Title"].encode("ascii")
    assert h["Priority"] == "high" and "possivel compra" in h["Title"]
    assert "Qualidade" in body.decode() and "Aplicar" in body.decode()
    from marketalerts.models import Opportunity
    n.send(Opportunity("AAPL", "STOP_HIT", 94.0, "r"))
    assert calls[1][1]["Priority"] == "urgent" and "STOP" in calls[1][1]["Title"]


# ---- migração de base de dados antiga
def test_migrates_old_alerts_table(tmp_path):
    import sqlite3
    path = str(tmp_path / "old.db")
    db = sqlite3.connect(path)
    db.execute("CREATE TABLE alerts(id INTEGER PRIMARY KEY, ts REAL, key TEXT, symbol TEXT, kind TEXT, price REAL, stop REAL, reason TEXT)")
    db.execute("INSERT INTO alerts(ts,key,symbol,kind,price,stop,reason) VALUES(1,'X:BUY_DIP','X','BUY_DIP',10,9,'velho')")
    db.commit(); db.close()
    s = Store(path)
    assert s.pending_alerts()[0]["reason"] == "velho"


# ---- API HTTP
@pytest.fixture
def server(st):
    srv = serve(st, 0)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    yield f"http://127.0.0.1:{srv.server_address[1]}", st
    srv.shutdown()

def call(base, path, method="GET", body=None):
    req = urllib.request.Request(base + path, method=method,
        data=json.dumps(body).encode() if body is not None else None,
        headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req) as r: return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e: return e.code, json.loads(e.read())

def test_http_apply_reject_close_flow(server):
    base, st = server
    run_once(["A", "B"], Prov(dip_series()), Sink(), st, now=1000)
    alerts = call(base, "/api/alerts")[1]
    assert {a["symbol"] for a in alerts} == {"A", "B"} and all("reason" in a and "ts" in a for a in alerts)
    a, b = alerts
    assert call(base, f"/api/alerts/{a['id']}/reject", "POST")[0] == 200
    code, out = call(base, f"/api/alerts/{b['id']}/apply", "POST")
    assert code == 201 and "position_id" in out
    assert call(base, "/api/alerts")[1] == []                       # rejeitado e aplicado saem da lista
    pos = call(base, "/api/positions")[1]
    assert len(pos) == 1 and pos[0]["symbol"] == b["symbol"]
    assert call(base, f"/api/alerts/{b['id']}/apply", "POST")[0] == 404   # já tratado
    assert call(base, f"/api/positions/{pos[0]['id']}/close", "POST")[0] == 200
    assert call(base, "/api/positions")[1] == []
    assert call(base, "/api/positions/999/close", "POST")[0] == 404

def test_page_has_buttons_and_sections(server):
    base, _ = server
    html = urllib.request.urlopen(base + "/").read().decode()
    for needle in ("Aplicar", "Rejeitar", "Emitido", "Marcar como vendida", "aguardam sinal de venda"):
        assert needle in html
