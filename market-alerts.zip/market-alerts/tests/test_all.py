import math
from datetime import datetime, timedelta
import pytest
from marketalerts.indicators import atr, rsi, sma, zscore
from marketalerts.models import Bar, Opportunity
from marketalerts.notifier import NtfyNotifier, format_message
from marketalerts.rules import RuleConfig, evaluate
from marketalerts.scanner import run_once
from marketalerts.store import Store

T0 = datetime(2026, 1, 1)


def mk(closes, spread=1.0):
    return [Bar(T0 + timedelta(days=i), c, c + spread, c - spread, c, 1000) for i, c in enumerate(closes)]


def flat_noise(n=60, base=100.0):
    return [base + (1 if i % 2 else -1) * 0.5 for i in range(n)]


# ---- indicadores
def test_sma():
    assert sma([1, 2, 3, 4], 2) == 3.5

def test_zscore_flat_is_zero():
    assert zscore([5.0] * 20, 20) == 0.0

def test_zscore_known():
    v = [0.0] * 19 + [10.0]
    assert zscore(v, 20) == pytest.approx(math.sqrt(19), rel=1e-6)

def test_rsi_extremes():
    assert rsi([float(i) for i in range(1, 40)]) == 100.0
    assert rsi([float(i) for i in range(40, 1, -1)]) == pytest.approx(0.0, abs=1e-9)

def test_rsi_reference_value():
    # série clássica de Wilder (14 períodos) -> ~70.46 com 15 fechos
    c = [44.34, 44.09, 44.15, 43.61, 44.33, 44.83, 45.10, 45.42, 45.84, 46.08,
         45.89, 46.03, 45.61, 46.28, 46.28]
    assert rsi(c, 14) == pytest.approx(70.46, abs=0.1)

def test_atr_constant_range():
    bars = mk([100.0] * 30, spread=1.0)
    assert atr(bars, 14) == pytest.approx(2.0)

def test_not_enough_data():
    with pytest.raises(ValueError):
        rsi([1, 2, 3])


# ---- regras
def dip_series():
    c = flat_noise(55)
    c += [97, 93, 89, 85, 80]          # queda forte
    return mk(c)

def test_dip_without_news_triggers_buy_with_stop():
    bars = dip_series()
    o = evaluate("TEST", bars, news_count=0)
    assert o and o.kind == "BUY_DIP"
    assert o.stop_loss < o.price < o.target
    a = atr(bars)
    assert o.stop_loss == pytest.approx(o.price - 2 * a, abs=1e-3)
    assert o.risk_pct == pytest.approx((o.price - o.stop_loss) / o.price * 100, abs=0.01)

def test_dip_with_news_is_ignored():
    assert evaluate("TEST", dip_series(), news_count=3) is None

def test_dip_with_unknown_news_is_ignored():
    assert evaluate("TEST", dip_series(), news_count=None) is None

def test_stretch_triggers_sell():
    c = flat_noise(55) + [102, 105, 109, 113, 118]
    o = evaluate("TEST", mk(c), news_count=0)
    assert o and o.kind == "SELL_STRETCH" and o.stop_loss is None

def test_quiet_market_no_signal():
    assert evaluate("TEST", mk(flat_noise(60)), news_count=0) is None

def test_too_few_bars():
    assert evaluate("TEST", mk(flat_noise(10)), news_count=0) is None


# ---- notificador
def test_ntfy_payload():
    calls = []
    n = NtfyNotifier("topico", post=lambda u, d, h: calls.append((u, d, h)) or 200)
    o = Opportunity("AAPL", "BUY_DIP", 100.0, "razão", stop_loss=95.0, target=110.0, risk_pct=5.0)
    assert n.send(o) == 200
    url, body, headers = calls[0]
    assert url == "https://ntfy.sh/topico"
    assert b"95.0" in body and "AAPL" in headers["Title"] and headers["Priority"] == "high"

def test_format_sell_has_no_stop():
    t, b = format_message(Opportunity("QQQ", "SELL_STRETCH", 500.0, "x"))
    assert "Stop-loss" not in b


# ---- store + scanner
class FakeProvider:
    def __init__(self, bars, news=0): self.bars, self.news = bars, news
    def get_bars(self, s, d): 
        if s == "BAD": raise RuntimeError("falha de rede")
        return self.bars
    def news_count(self, s, h): return self.news

class Sink:
    def __init__(self, fail=False): self.sent, self.fail = [], fail
    def send(self, o):
        if self.fail: raise RuntimeError("ntfy em baixo")
        self.sent.append(o)



# ---- Twelve Data (resposta simulada: formato assumido, ver aviso no código)
from marketalerts.providers import TwelveDataProvider

def td_payload(n=3):
    vals = [{"datetime": f"2026-11-{18 - i:02d}", "open": "10", "high": "11", "low": "9",
             "close": str(10 + i), "volume": "100"} for i in range(n)]  # mais recente primeiro
    return {"meta": {"symbol": "X"}, "values": vals, "status": "ok"}

def test_twelvedata_parses_and_sorts_ascending():
    seen = {}
    def fake(url, headers): seen.update(url=url, headers=headers); return td_payload()
    bars = TwelveDataProvider("KEY", http_get=fake, sleep=lambda s: None).get_bars("AAPL", 50)
    assert [b.ts.day for b in bars] == [16, 17, 18]
    assert bars[-1].close == 10.0 and isinstance(bars[0].high, float)
    assert "symbol=AAPL" in seen["url"] and "interval=1day" in seen["url"] and "outputsize=50" in seen["url"]
    assert "KEY" not in seen["url"] and seen["headers"]["Authorization"] == "apikey KEY"

def test_twelvedata_error_has_no_key_leak():
    err = {"code": 429, "message": "limite atingido", "status": "error"}
    p = TwelveDataProvider("SEGREDO", http_get=lambda u, h: err, sleep=lambda s: None)
    with pytest.raises(RuntimeError) as e:
        p.get_bars("AAPL")
    assert "429" in str(e.value) and "SEGREDO" not in str(e.value)

def test_twelvedata_throttle_spaces_calls():
    t = [0.0]; sleeps = []
    def sleep(s): sleeps.append(s); t[0] += s
    p = TwelveDataProvider("K", calls_per_minute=8, http_get=lambda u, h: td_payload(),
                           sleep=sleep, clock=lambda: t[0])
    p.get_bars("A"); p.get_bars("B"); p.get_bars("C")
    assert sleeps == [pytest.approx(7.5), pytest.approx(7.5)]

def test_twelvedata_missing_volume_ok():
    d = td_payload(1); del d["values"][0]["volume"]
    bars = TwelveDataProvider("K", http_get=lambda u, h: d, sleep=lambda s: None).get_bars("ETF")
    assert bars[0].volume == 0.0

def test_unverified_news_flag():
    assert evaluate("T", dip_series(), None) is None
    o = evaluate("T", dip_series(), None, RuleConfig(allow_unverified_news=True))
    assert o and o.kind == "BUY_DIP" and "NÃO verificadas" in o.reason
