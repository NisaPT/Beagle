from dataclasses import dataclass, field
from datetime import datetime


@dataclass(frozen=True)
class Bar:
    ts: datetime
    open: float
    high: float
    low: float
    close: float
    volume: float = 0.0


@dataclass
class Opportunity:
    symbol: str
    kind: str            # BUY_DIP | SELL_STRETCH | STOP_HIT | TARGET_HIT
    price: float
    reason: str
    stop_loss: float | None = None
    target: float | None = None
    risk_pct: float | None = None
    score: int = 0
    max_score: int = 0
    valuation: str = ""
    metrics: dict = field(default_factory=dict)

    @property
    def key(self) -> str:
        return f"{self.symbol}:{self.kind}"
