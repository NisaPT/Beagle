"""Fontes de dados. Interface: get_bars(symbol, days) -> list[Bar]; news_count(symbol, hours).

NOTA: YahooProvider usa a biblioteca não-oficial yfinance (dados com atraso,
pode quebrar). Não foi testada com dados reais neste ambiente (rede bloqueada)."""
from __future__ import annotations
import json
import re
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from urllib.parse import urlencode

from .models import Bar


class Throttle:
    """Espaça pedidos para respeitar o limite por minuto do plano."""

    def __init__(self, calls_per_minute: int, sleep=None, clock=None):
        self.gap = 60.0 / calls_per_minute
        self._sleep = sleep or time.sleep
        self._clock = clock or time.monotonic
        self._last = None

    def wait(self):
        now = self._clock()
        if self._last is not None and now - self._last < self.gap:
            self._sleep(self.gap - (now - self._last))
            now = self._clock()
        self._last = now


def _http_get_json(url: str, headers: dict | None = None):
    req = urllib.request.Request(url, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return json.load(r)
    except urllib.error.HTTPError as e:
        detail = ""
        try:  # o corpo costuma explicar o motivo (plano, símbolo, limite...)
            body = json.loads(e.read().decode("utf-8", "replace"))
            err = body.get("error", body.get("message")) if isinstance(body, dict) else None
            detail = err.get("message", "") if isinstance(err, dict) else str(err or "")
        except Exception:
            pass
        raise RuntimeError(f"HTTP {e.code}" + (f": {detail[:200]}" if detail else "")) from None


CATALYST_RE = re.compile(
    r"\b(earnings?|guidance|outlook|forecast|downgrad\w*|upgrad\w*|lawsuit|sues?|sued|probe|"
    r"investigat\w*|subpoena|sec|fda|recall\w*|fraud|bankrupt\w*|layoffs?|restructur\w*|resigns?|"
    r"ceo|cfo|acqui\w*|merger|buyout|offering|dividend|split|misses|beats|plunge[sd]?|tumbl\w*|"
    r"slump\w*|warns?|warning|cuts?|halt\w*|antitrust|tariffs?|ban|bans|banned)\b", re.I)


def has_catalyst(text: str) -> bool:
    """Heurística: a manchete menciona um possível motivo concreto (resultados, rebaixamento,
    processo, aquisição...). Lista simples, em inglês; ajustável."""
    return bool(CATALYST_RE.search(text or ""))


class YahooProvider:
    def get_bars(self, symbol: str, days: int = 120) -> list[Bar]:
        import yfinance as yf  # import tardio: dependência opcional
        df = yf.Ticker(symbol).history(period="2y", interval="1d", auto_adjust=False).tail(days)
        return [Bar(ts.to_pydatetime(), float(r.Open), float(r.High), float(r.Low),
                    float(r.Close), float(r.Volume)) for ts, r in df.iterrows()]

    def news_count(self, symbol: str, hours: int = 48) -> int | None:
        import time
        import yfinance as yf
        try:
            items = yf.Ticker(symbol).news or []
        except Exception:
            return None
        cutoff = time.time() - hours * 3600
        n = 0
        for it in items:
            ts = it.get("providerPublishTime") or (it.get("content") or {}).get("pubTimestamp")
            if isinstance(ts, (int, float)) and ts >= cutoff:
                n += 1
            elif not isinstance(ts, (int, float)):
                n += 1  # sem data fiável: assume recente (conservador)
        return n


class TwelveDataProvider:
    """Twelve Data REST. Formato da resposta assumido a partir da documentação
    (time_series: values/datetime/open/high/low/close/volume; price: {"price": "..."};
    erros {code,message,status}) mas NÃO validado com dados reais: usa --diagnose.
    Plano gratuito: 8 pedidos/min e 800/dia -> throttle incluído."""
    URL = "https://api.twelvedata.com/time_series"
    PRICE_URL = "https://api.twelvedata.com/price"

    def __init__(self, apikey: str, calls_per_minute: int = 8, http_get=None,
                 sleep=None, clock=None):
        self.apikey = apikey
        self._get = http_get or _http_get_json
        self._throttle = Throttle(calls_per_minute, sleep, clock)

    def _call(self, url: str) -> dict:
        self._throttle.wait()
        data = self._get(url, {"Authorization": f"apikey {self.apikey}"})
        if not isinstance(data, dict):
            raise RuntimeError("resposta inesperada do Twelve Data")
        if data.get("status") == "error":
            raise RuntimeError(f"Twelve Data {data.get('code', '?')}: {data.get('message', 'sem detalhe')}")
        return data

    def get_bars(self, symbol: str, days: int = 120) -> list[Bar]:
        data = self._call(self.URL + "?" + urlencode({"symbol": symbol, "interval": "1day", "outputsize": days}))
        if "values" not in data:
            raise RuntimeError(f"Twelve Data: sem 'values' para {symbol}")
        bars = []
        for v in data["values"]:
            bars.append(Bar(datetime.fromisoformat(v["datetime"]), float(v["open"]), float(v["high"]),
                            float(v["low"]), float(v["close"]), float(v.get("volume") or 0)))
        bars.sort(key=lambda b: b.ts)  # independente da ordem devolvida
        return bars

    def get_quote(self, symbol: str) -> float:
        data = self._call(self.PRICE_URL + "?" + urlencode({"symbol": symbol}))
        price = float(data["price"]) if "price" in data else None
        if not price or price <= 0:
            raise RuntimeError(f"Twelve Data: sem preço para {symbol}")
        return price

    def news_count(self, symbol: str, hours: int = 48):
        return None  # sem fonte de notícias ligada


class FinnhubProvider:
    """Finnhub: cotação em tempo quase real (/quote) e notícias de empresa (/company-news,
    só empresas norte-americanas). Endpoints e campos (c,h,l,o,pc,t; datetime) vêm de
    documentação de terceiros e NÃO foram validados com dados reais: usa --diagnose.
    Plano gratuito: ~60 pedidos/min (usamos 50 por segurança)."""
    BASE = "https://finnhub.io/api/v1"

    def __init__(self, apikey: str, calls_per_minute: int = 50, http_get=None,
                 sleep=None, clock=None, now=None):
        self.apikey = apikey
        self._get = http_get or _http_get_json
        self._throttle = Throttle(calls_per_minute, sleep, clock)
        self._now = now or time.time

    def _call(self, path: str, **params):
        self._throttle.wait()
        data = self._get(f"{self.BASE}/{path}?{urlencode(params)}", {"X-Finnhub-Token": self.apikey})
        if isinstance(data, dict) and data.get("error"):
            raise RuntimeError(f"Finnhub: {data['error']}")
        return data

    def get_quote(self, symbol: str) -> float:
        d = self._call("quote", symbol=symbol)
        price = d.get("c") if isinstance(d, dict) else None
        if not price or price <= 0:  # Finnhub devolve zeros para símbolos desconhecidos
            raise RuntimeError(f"Finnhub: sem cotação para {symbol}")
        return float(price)

    def _recent(self, symbol: str, hours: int) -> list[dict]:
        now = self._now()
        frm = datetime.fromtimestamp(now - hours * 3600, timezone.utc).strftime("%Y-%m-%d")
        to = datetime.fromtimestamp(now + 86400, timezone.utc).strftime("%Y-%m-%d")
        items = self._call("company-news", symbol=symbol, **{"from": frm, "to": to})
        if not isinstance(items, list):
            raise RuntimeError("Finnhub: resposta de notícias inesperada")
        cutoff = now - hours * 3600
        return [it for it in items if isinstance(it.get("datetime"), (int, float)) and it["datetime"] >= cutoff]

    def news_count(self, symbol: str, hours: int = 48):
        return len(self._recent(symbol, hours))

    def headlines(self, symbol: str, hours: int = 48, limit: int = 3) -> list[str]:
        return [str(it.get("headline", "")) for it in self._recent(symbol, hours)][:limit]

    def catalyst_count(self, symbol: str, hours: int = 48):
        """Notícias recentes cuja manchete sugere um motivo concreto (sem texto = conta como motivo)."""
        return sum(1 for it in self._recent(symbol, hours)
                   if not (it.get("headline") or "").strip() or has_catalyst(it["headline"] + " " + (it.get("summary") or "")))


class MarketauxNews:
    """Marketaux: notícias globais (útil para ações europeias). Plano gratuito: 100 pedidos/dia.
    Parâmetros/resposta (meta.found, data) assumidos da documentação, NÃO validados."""
    URL = "https://api.marketaux.com/v1/news/all"

    def __init__(self, token: str, http_get=None, now=None):
        self.token = token
        self._get = http_get or _http_get_json
        self._now = now or time.time

    def _fetch(self, symbol: str, hours: int, limit: int = 3) -> dict:
        since = datetime.fromtimestamp(self._now() - hours * 3600, timezone.utc).strftime("%Y-%m-%dT%H:%M:%S")
        data = self._get(self.URL + "?" + urlencode({"symbols": symbol, "filter_entities": "true",
                         "published_after": since, "limit": limit, "api_token": self.token}), {})
        if not isinstance(data, dict) or data.get("error"):
            msg = (data.get("error") or {}).get("message", "erro") if isinstance(data, dict) else "resposta inesperada"
            raise RuntimeError(f"Marketaux: {msg}")  # sem o token na mensagem
        return data

    def news_count(self, symbol: str, hours: int = 48):
        data = self._fetch(symbol, hours)
        found = (data.get("meta") or {}).get("found")
        return int(found) if isinstance(found, (int, float)) else len(data.get("data") or [])

    def headlines(self, symbol: str, hours: int = 48, limit: int = 3) -> list[str]:
        return [str(it.get("title", "")) for it in (self._fetch(symbol, hours, limit).get("data") or [])][:limit]

    def catalyst_count(self, symbol: str, hours: int = 48):
        """Só vê os artigos devolvidos (plano grátis: 3 por pedido); se encontrou mais do que
        os devolvidos, assume que há motivo (muita cobertura)."""
        data = self._fetch(symbol, hours)
        items = data.get("data") or []
        n = sum(1 for it in items if has_catalyst((it.get("title") or "") + " " + (it.get("description") or "")))
        found = (data.get("meta") or {}).get("found")
        return n + (1 if isinstance(found, (int, float)) and found > len(items) and n == 0 else 0)


class NewsRouter:
    """Símbolos com sufixo de bolsa (ex.: VWCE.DE) -> fonte internacional; os restantes -> EUA.
    Heurística: o Finnhub só cobre empresas norte-americanas, e devolver 0 para um ativo
    europeu seria um falso 'sem notícias'."""

    def __init__(self, us=None, intl=None):
        self.us, self.intl = us, intl

    def _src(self, symbol: str):
        return self.intl if "." in symbol else self.us

    def news_count(self, symbol: str, hours: int = 48):
        src = self._src(symbol)
        return None if src is None else src.news_count(symbol, hours)

    def catalyst_count(self, symbol: str, hours: int = 48):
        src = self._src(symbol)
        return None if src is None else src.catalyst_count(symbol, hours)

    def headlines(self, symbol: str, hours: int = 48, limit: int = 3):
        src = self._src(symbol)
        return [] if src is None else src.headlines(symbol, hours, limit)
