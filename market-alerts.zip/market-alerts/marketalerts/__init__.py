"""Scanner de oportunidades para ações/ETFs/cripto (sinais, não aconselhamento financeiro)."""
