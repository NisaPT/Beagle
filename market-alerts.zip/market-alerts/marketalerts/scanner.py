from __future__ import annotations
import logging
from dataclasses import replace
from .models import Opportunity
from .monitor import stop_target_signal
from .rules import RuleConfig, evaluate

log = logging.getLogger("scanner")


def _check_position(pos, bars, opp):
    """Sinal de venda ao fecho da vela (rede de segurança; o stop em tempo real é do monitor)."""
    last = bars[-1].close
    pl = (last / pos["entry"] - 1) * 100
    sig = stop_target_signal(pos, last)
    if sig:
        return sig
    if opp is not None and opp.kind == "SELL_STRETCH":
        return "SELL_STRETCH", f"{opp.reason} Resultado atual {pl:+.1f}%."
    return None


def run_once(symbols, provider, notifier, store, cfg: RuleConfig | None = None,
             cooldown_s: float = 24 * 3600, now: float | None = None, news=None, news_mode: str = "catalyst",
             etfs=()) -> list[Opportunity]:
    cfg = cfg or RuleConfig()
    news = news or provider  # objeto com news_count(symbol, hours)
    # 'catalyst': só contam notícias cujas manchetes sugerem um motivo concreto; 'count': todas.
    news_fn = (getattr(news, "catalyst_count", None) if news_mode == "catalyst" else None) or news.news_count
    etfs = {e.upper() for e in etfs}
    sent: list[Opportunity] = []

    # 1) reenviar push de alertas que ficaram por notificar
    for aid, opp in store.unnotified():
        try:
            notifier.send(opp)
            store.mark_notified(aid)
        except Exception as e:
            log.warning("%s: reenvio falhou: %s", opp.symbol, e)

    held = {p["symbol"]: p for p in store.open_positions()}
    for sym in sorted(set(symbols) | set(held)):
        pos = held.get(sym)
        try:
            bars = provider.get_bars(sym, cfg.history_days)
            # notícias só são pedidas se o preço já justificar um alerta (poupa quota)
            if pos:
                opp = evaluate(sym, bars, 0, cfg)
            elif sym.upper() in etfs:  # ETFs: notícias de empresa não se aplicam -> alerta sem essa verificação
                opp = evaluate(sym, bars, None, replace(cfg, allow_unverified_news=True))
            else:
                opp = evaluate(sym, bars, lambda s=sym: news_fn(s, 48), cfg)
        except Exception as e:  # uma falha num símbolo não pára o resto
            log.warning("%s: erro %s", sym, e)
            continue

        if pos:  # --- posição aplicada: à espera do sinal de venda
            store.update_price(pos["id"], bars[-1].close, now)
            if pos["status"] != "open":
                continue
            res = _check_position(pos, bars, opp)
            if not res:
                continue
            kind, reason = res
            sell = Opportunity(sym, kind, bars[-1].close, reason, pos["stop"], pos["target"])
            try:
                notifier.send(sell)
            except Exception as e:
                log.warning("%s: falha no envio da venda: %s", sym, e)
                continue  # tenta de novo no próximo ciclo
            store.set_sell_signal(pos["id"], kind, reason, now)
            sent.append(sell)
            continue

        # --- símbolo livre: só interessam alertas de compra
        if opp is None or opp.kind != "BUY_DIP":
            continue
        if store.has_pending(opp.key) or store.recently_sent(opp.key, cooldown_s, now):
            continue
        aid = store.record(opp, now)  # fica visível na app mesmo que o push falhe
        try:
            notifier.send(opp)
            store.mark_notified(aid)
        except Exception as e:
            log.warning("%s: falha no envio: %s (será repetido)", sym, e)
        sent.append(opp)
    return sent
