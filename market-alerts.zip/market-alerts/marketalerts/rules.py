"""Regras de deteção. Todos os limiares são configuráveis e DEVEM ser validados
com backtest antes de se confiar neles."""
from __future__ import annotations
from dataclasses import dataclass
from .indicators import atr, rsi, zscore
from .models import Bar, Opportunity
from .valuation import valuation


@dataclass
class RuleConfig:
    z_window: int = 20
    buy_z: float = -2.0          # z-score <= isto
    buy_rsi: float = 32.0        # RSI <= isto
    min_drop_pct: float = 4.0    # queda no último dia (%) >= isto
    sell_z: float = 2.0
    sell_rsi: float = 70.0
    sell_run_pct: float = 10.0   # subida em 5 barras (%) >= isto
    atr_period: int = 14
    stop_atr_mult: float = 2.0
    rr_target: float = 2.0       # alvo = entrada + rr * risco
    min_bars: int = 40
    history_days: int = 260      # barras pedidas ao fornecedor (52 semanas + margem)
    cheap_pos: float = 0.35      # posição no intervalo 52s <= isto: 'barato'
    expensive_pos: float = 0.80  # >= isto: 'caro'
    min_score: int = 4           # confirmações mínimas (de 7) para emitir alerta de compra
    allow_unverified_news: bool = False  # True: alerta mesmo sem fonte de notícias (com aviso)


def evaluate(symbol: str, bars: list[Bar], news_count: int | None,
             cfg: RuleConfig | None = None) -> Opportunity | None:
    """news_count: nº de notícias recentes, None (fonte indisponível) ou função sem
    argumentos que o devolve (só é chamada quando o preço já justifica um alerta,
    para poupar pedidos às fontes de notícias)."""
    cfg = cfg or RuleConfig()
    if len(bars) < cfg.min_bars:
        return None
    closes = [b.close for b in bars]
    last, prev = closes[-1], closes[-2]
    day_chg = (last / prev - 1) * 100
    run5 = (last / closes[-6] - 1) * 100
    z = zscore(closes, cfg.z_window)
    r = rsi(closes)
    a = atr(bars, cfg.atr_period)
    m = {"z": round(z, 2), "rsi": round(r, 1), "dia_%": round(day_chg, 2),
         "5d_%": round(run5, 2), "atr": round(a, 4)}

    # Queda sem motivo aparente -> possível compra
    dip = (z <= cfg.buy_z and r <= cfg.buy_rsi) or (-day_chg >= cfg.min_drop_pct and z <= cfg.buy_z)
    val = valuation(bars, cfg.cheap_pos, cfg.expensive_pos)
    vtext = val["text"] if val else ""
    if dip:
        if callable(news_count):
            try:
                news_count = news_count()
            except Exception:
                news_count = None
        if news_count is None and not cfg.allow_unverified_news:
            return None  # sem fonte de notícias não afirmamos "sem motivo"
        if news_count in (0, None):
            warn = " ⚠ Notícias NÃO verificadas." if news_count is None else ""
            score = (int(z <= cfg.buy_z) + int(z <= cfg.buy_z - 1) + int(r <= cfg.buy_rsi)
                     + int(r <= cfg.buy_rsi - 7) + int(news_count == 0) + int(-day_chg >= cfg.min_drop_pct))
            if val:  # barato dá +1, caro tira 1
                score += int(val["label"] == "barato") - int(val["label"] == "caro")
            score = max(0, score)
            if score < cfg.min_score:
                return None
            m["score"] = score
            stop = last - cfg.stop_atr_mult * a
            risk = last - stop
            return Opportunity(
                symbol, "BUY_DIP", last,
                f"Queda ({day_chg:+.1f}% hoje; z={z:.1f}, RSI={r:.0f}) sem notícias recentes.{warn}"
                if news_count == 0 else
                f"Queda ({day_chg:+.1f}% hoje; z={z:.1f}, RSI={r:.0f}).{warn}",
                stop_loss=round(stop, 4), target=round(last + cfg.rr_target * risk, 4),
                risk_pct=round(risk / last * 100, 2), score=score, max_score=7, valuation=vtext, metrics=m)
        return None  # há notícias: queda provavelmente justificada

    # Subida excessiva -> possível realização de lucro
    if (z >= cfg.sell_z and r >= cfg.sell_rsi) or run5 >= cfg.sell_run_pct:
        return Opportunity(
            symbol, "SELL_STRETCH", last,
            f"Subida esticada ({run5:+.1f}% em 5 dias; z={z:.1f}, RSI={r:.0f})."
            + (" Preço caro face ao último ano." if val and val["label"] == "caro" else ""),
            valuation=vtext, metrics=m)
    return None
