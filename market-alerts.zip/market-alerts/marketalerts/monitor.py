"""Monitorização rápida das posições aplicadas: stop/alvo contra o preço ATUAL (não o fecho)."""
from __future__ import annotations
import logging
from .models import Opportunity

log = logging.getLogger("monitor")


def stop_target_signal(pos: dict, price: float):
    pl = (price / pos["entry"] - 1) * 100
    if pos.get("stop") is not None and price <= pos["stop"]:
        return "STOP_HIT", f"Preço {price:.2f} atingiu o stop-loss {pos['stop']:.2f} (resultado {pl:+.1f}%)."
    if pos.get("target") is not None and price >= pos["target"]:
        return "TARGET_HIT", f"Preço {price:.2f} atingiu o alvo {pos['target']:.2f} (resultado {pl:+.1f}%)."
    return None


def check_positions(store, quote_fn, notifier, now: float | None = None) -> list[Opportunity]:
    """Uma passagem: lê o preço atual de cada posição aberta e emite o sinal de venda
    (push + registo) se o stop ou o alvo foi tocado. Cada posição só alerta uma vez."""
    sent = []
    for pos in store.open_positions():
        if pos["status"] != "open":
            continue
        try:
            price = quote_fn(pos["symbol"])
        except Exception as e:
            log.warning("%s: sem cotação (%s)", pos["symbol"], e)
            continue
        store.update_price(pos["id"], price, now)
        sig = stop_target_signal(pos, price)
        if not sig:
            continue
        kind, reason = sig
        opp = Opportunity(pos["symbol"], kind, price, reason, pos["stop"], pos["target"])
        try:
            notifier.send(opp)
        except Exception as e:
            log.warning("%s: falha no envio da venda: %s (repete)", pos["symbol"], e)
            continue
        store.set_sell_signal(pos["id"], kind, reason, now)
        sent.append(opp)
    return sent
