import argparse, json, logging, os, time
from .monitor import check_positions
from .notifier import NtfyNotifier
from .providers import FinnhubProvider, MarketauxNews, NewsRouter, TwelveDataProvider, YahooProvider
from .rules import RuleConfig
from .scanner import run_once
from .store import Store


def _need(var):
    v = os.environ.get(var)
    if not v:
        raise SystemExit(f"Define a variável de ambiente {var}")
    return v


def _news_summary(news_src, sym):
    if news_src is None:
        return "sem fonte de notícias (news)"
    total = news_src.news_count(sym, 48)
    cat = news_src.catalyst_count(sym, 48) if hasattr(news_src, "catalyst_count") else "n/d"
    heads = news_src.headlines(sym, 48, 3) if hasattr(news_src, "headlines") else []
    out = f"{total} no total, {cat} com possível motivo concreto"
    for h in heads:
        out += f"\n      - {h[:110]}"
    if total and not heads:
        out += "\n      (AVISO: há notícias mas nenhuma manchete lida: campos da API diferentes do esperado)"
    return out


def build_sources(c):
    """Fornecedor de barras diárias, fonte de cotações em tempo real e fonte de notícias."""
    name = c.get("provider", "yahoo")
    bars = (TwelveDataProvider(_need("TWELVEDATA_API_KEY"), c.get("calls_per_minute", 8))
            if name == "twelvedata" else YahooProvider())
    q = c.get("quote_source", name)
    quote = (FinnhubProvider(_need("FINNHUB_API_KEY"), c.get("finnhub_calls_per_minute", 50)) if q == "finnhub"
             else bars if q == "twelvedata" else None)
    n = c.get("news", "none")
    fh = quote if isinstance(quote, FinnhubProvider) else (
        FinnhubProvider(_need("FINNHUB_API_KEY")) if n in ("finnhub", "auto") else None)
    news = None
    if n == "finnhub":
        news = NewsRouter(us=fh)
    elif n == "marketaux":
        mk = MarketauxNews(_need("MARKETAUX_API_KEY"))
        news = NewsRouter(us=mk, intl=mk)
    elif n == "auto":  # EUA -> Finnhub; símbolos com sufixo (VWCE.DE) -> Marketaux
        news = NewsRouter(us=fh, intl=MarketauxNews(_need("MARKETAUX_API_KEY")) if os.environ.get("MARKETAUX_API_KEY") else None)
    return bars, quote, news


def main():
    p = argparse.ArgumentParser(prog="marketalerts")
    p.add_argument("--config", default="config.json")
    p.add_argument("--loop", type=int, default=0, help="scanner: repetir a cada N segundos (0 = uma vez)")
    p.add_argument("--monitor", type=int, default=0,
                   help="monitor de stop/alvo em tempo quase real: verifica as posições a cada N segundos")
    p.add_argument("--diagnose", nargs="+", metavar="SIMBOLO",
                   help="testa as fontes (barras, cotação, notícias) com estes símbolos")
    p.add_argument("--dry-run", action="store_true", help="não envia push; só imprime")
    a = p.parse_args()
    logging.basicConfig(level=logging.INFO)
    c = json.load(open(a.config))
    cfg = RuleConfig(**c.get("rules", {}))
    store = Store(c.get("db", "alerts.db"))

    class Print:
        def send(self, o): print(o)
    notifier = Print() if a.dry_run else NtfyNotifier(c["ntfy_topic"])
    bars_src, quote_src, news_src = build_sources(c)

    if a.diagnose:
        for sym in a.diagnose:
            for label, fn in (
                ("barras", lambda: (lambda b: f"{len(b)} barras, {b[0].ts.date()} -> {b[-1].ts.date()}, último fecho {b[-1].close}")(bars_src.get_bars(sym, cfg.history_days))),
                ("cotação", lambda: f"{quote_src.get_quote(sym)}" if quote_src else "sem fonte de cotações (quote_source)"),
                ("notícias 48h", lambda: _news_summary(news_src, sym))):
                try:
                    print(f"{sym} {label}: {fn()}")
                except Exception as e:
                    print(f"{sym} {label}: ERRO {e}")
        return

    if a.monitor:
        if quote_src is None:
            raise SystemExit("Define quote_source (finnhub ou twelvedata) no config para usar --monitor")
        while True:
            for o in check_positions(store, quote_src.get_quote, notifier):
                logging.info("venda: %s %s", o.symbol, o.kind)
            time.sleep(a.monitor)

    while True:
        for o in run_once(store.all_symbols() or c["symbols"], bars_src, notifier, store, cfg, news=news_src,
                           news_mode=c.get("news_mode", "catalyst"), etfs=c.get("etfs", [])):
            logging.info("alerta: %s %s", o.symbol, o.kind)
        if not a.loop:
            break
        time.sleep(a.loop)


if __name__ == "__main__":
    main()
