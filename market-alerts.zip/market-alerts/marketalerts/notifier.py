"""Push via ntfy (https://ntfy.sh). O 'post' é injetável para testes."""
from __future__ import annotations
import unicodedata
import urllib.request
from .models import Opportunity


def _default_post(url: str, data: bytes, headers: dict) -> int:
    req = urllib.request.Request(url, data=data, headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=10) as r:
        return r.status


def _ascii(text: str) -> str:
    """Cabeçalhos HTTP são latin-1: removemos acentos do título para evitar texto corrompido."""
    return unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode()


def format_message(o: Opportunity) -> tuple[str, str]:
    disclaimer = "Sinal estatistico, nao recomendacao."
    if o.kind == "BUY_DIP":
        title = f"{o.symbol}: possível compra a {o.price:.2f}"
        body = (f"{o.reason}\nQualidade: {o.score}/{o.max_score} confirmações.\n"
                f"Valorização: {o.valuation or 'n/d'}\n"
                f"Stop-loss sugerido: {o.stop_loss} (risco {o.risk_pct}%)\nAlvo (R:R): {o.target}\n"
                "Abre a app para Aplicar ou Rejeitar. Sinal estatístico, não recomendação.")
    elif o.kind == "STOP_HIT":
        title = f"{o.symbol}: STOP atingido a {o.price:.2f}"
        body = f"{o.reason}\nPosição aplicada em monitorização. Decide tu."
    elif o.kind == "TARGET_HIT":
        title = f"{o.symbol}: alvo atingido a {o.price:.2f}"
        body = f"{o.reason}\nPosição aplicada em monitorização. Decide tu."
    else:
        title = f"{o.symbol}: possível venda/realização de lucro a {o.price:.2f}"
        body = f"{o.reason}\nSinal estatístico, não recomendação."
    return title, body


_PRIO = {"BUY_DIP": "high", "STOP_HIT": "urgent", "TARGET_HIT": "high", "SELL_STRETCH": "default"}
_TAGS = {"BUY_DIP": "chart_with_downwards_trend", "STOP_HIT": "rotating_light",
         "TARGET_HIT": "white_check_mark", "SELL_STRETCH": "chart_with_upwards_trend"}


class NtfyNotifier:
    def __init__(self, topic: str, server: str = "https://ntfy.sh", post=_default_post):
        self.url, self.post = f"{server.rstrip('/')}/{topic}", post

    def send(self, o: Opportunity) -> int:
        title, body = format_message(o)
        headers = {"Title": _ascii(title) or o.symbol,
                   "Priority": _PRIO.get(o.kind, "default"), "Tags": _TAGS.get(o.kind, "bell")}
        return self.post(self.url, body.encode("utf-8"), headers)
