import re
import sqlite3
import time

from .models import Opportunity

OPEN_STATES = ("open", "sell_signal")


class Store:
    """Alertas de compra (pending/applied/rejected), posições monitorizadas e watchlists."""

    SYMBOL_RE = re.compile(r"^[A-Z0-9][A-Z0-9.\-=^]{0,14}$")

    def __init__(self, path: str = "alerts.db"):
        self.db = sqlite3.connect(path, timeout=10, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA foreign_keys=ON")
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS watchlists(id INTEGER PRIMARY KEY, name TEXT NOT NULL UNIQUE);
        CREATE TABLE IF NOT EXISTS watchlist_symbols(
            watchlist_id INTEGER NOT NULL REFERENCES watchlists(id) ON DELETE CASCADE,
            symbol TEXT NOT NULL, PRIMARY KEY(watchlist_id, symbol));
        CREATE TABLE IF NOT EXISTS alerts(
            id INTEGER PRIMARY KEY, ts REAL, key TEXT, symbol TEXT, kind TEXT,
            price REAL, stop REAL, reason TEXT);
        CREATE TABLE IF NOT EXISTS positions(
            id INTEGER PRIMARY KEY, alert_id INTEGER, symbol TEXT NOT NULL,
            entry REAL, stop REAL, target REAL, applied_ts REAL,
            status TEXT NOT NULL DEFAULT 'open', last_price REAL, last_ts REAL,
            sell_kind TEXT, sell_reason TEXT, sell_ts REAL, closed_ts REAL);
        """)
        # migração de bases de dados antigas
        have = {r[1] for r in self.db.execute("PRAGMA table_info(alerts)")}
        for col, ddl in {"target": "REAL", "risk_pct": "REAL", "score": "INTEGER DEFAULT 0",
                         "max_score": "INTEGER DEFAULT 0", "status": "TEXT DEFAULT 'pending'",
                         "notified": "INTEGER DEFAULT 0", "valuation": "TEXT DEFAULT ''"}.items():
            if col not in have:
                self.db.execute(f"ALTER TABLE alerts ADD COLUMN {col} {ddl}")
        self.db.commit()

    # ---------------------------------------------------------------- alertas de compra
    def recently_sent(self, key: str, cooldown_s: float, now: float | None = None) -> bool:
        now = time.time() if now is None else now
        row = self.db.execute("SELECT MAX(ts) FROM alerts WHERE key=?", (key,)).fetchone()
        return row[0] is not None and now - row[0] < cooldown_s

    def has_pending(self, key: str) -> bool:
        return self.db.execute("SELECT 1 FROM alerts WHERE key=? AND status='pending'", (key,)).fetchone() is not None

    def record(self, opp: Opportunity, now: float | None = None) -> int:
        now = time.time() if now is None else now
        cur = self.db.execute(
            "INSERT INTO alerts(ts,key,symbol,kind,price,stop,target,risk_pct,score,max_score,reason,valuation,status,notified)"
            " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,'pending',0)",
            (now, opp.key, opp.symbol, opp.kind, opp.price, opp.stop_loss, opp.target,
             opp.risk_pct, opp.score, opp.max_score, opp.reason, opp.valuation))
        self.db.commit()
        return cur.lastrowid

    def mark_notified(self, aid: int):
        self.db.execute("UPDATE alerts SET notified=1 WHERE id=?", (aid,))
        self.db.commit()

    def unnotified(self) -> list[tuple[int, Opportunity]]:
        out = []
        for r in self.db.execute("SELECT * FROM alerts WHERE status='pending' AND notified=0 ORDER BY ts"):
            out.append((r["id"], Opportunity(r["symbol"], r["kind"], r["price"], r["reason"],
                                             r["stop"], r["target"], r["risk_pct"],
                                             r["score"] or 0, r["max_score"] or 0, r["valuation"] or "")))
        return out

    def pending_alerts(self) -> list[dict]:
        rows = self.db.execute(
            "SELECT id,ts,symbol,kind,price,stop,target,risk_pct,score,max_score,reason,valuation FROM alerts"
            " WHERE kind='BUY_DIP' AND status='pending' ORDER BY ts DESC")
        return [dict(r) for r in rows]

    def apply_alert(self, aid: int, now: float | None = None) -> int:
        """Aceita um alerta de compra: passa a posição monitorizada. Atómico."""
        now = time.time() if now is None else now
        cur = self.db.execute("UPDATE alerts SET status='applied' WHERE id=? AND status='pending' AND kind='BUY_DIP'", (aid,))
        if cur.rowcount == 0:
            self.db.rollback()
            raise KeyError("alerta inexistente ou já tratado")
        a = self.db.execute("SELECT * FROM alerts WHERE id=?", (aid,)).fetchone()
        pid = self.db.execute(
            "INSERT INTO positions(alert_id,symbol,entry,stop,target,applied_ts,status,last_price,last_ts)"
            " VALUES(?,?,?,?,?,?,'open',?,?)",
            (aid, a["symbol"], a["price"], a["stop"], a["target"], now, a["price"], now)).lastrowid
        self.db.commit()
        return pid

    def reject_alert(self, aid: int):
        cur = self.db.execute("UPDATE alerts SET status='rejected' WHERE id=? AND status='pending'", (aid,))
        self.db.commit()
        if cur.rowcount == 0:
            raise KeyError("alerta inexistente ou já tratado")

    # ---------------------------------------------------------------- posições
    def open_positions(self) -> list[dict]:
        q = "SELECT * FROM positions WHERE status IN (?,?) ORDER BY applied_ts DESC"
        return [dict(r) for r in self.db.execute(q, OPEN_STATES)]

    def held_symbols(self) -> set[str]:
        return {p["symbol"] for p in self.open_positions()}

    def update_price(self, pid: int, price: float, now: float | None = None):
        self.db.execute("UPDATE positions SET last_price=?, last_ts=? WHERE id=?",
                        (price, time.time() if now is None else now, pid))
        self.db.commit()

    def set_sell_signal(self, pid: int, kind: str, reason: str, now: float | None = None) -> bool:
        cur = self.db.execute(
            "UPDATE positions SET status='sell_signal', sell_kind=?, sell_reason=?, sell_ts=?"
            " WHERE id=? AND status='open'", (kind, reason, time.time() if now is None else now, pid))
        self.db.commit()
        return cur.rowcount > 0

    def close_position(self, pid: int, now: float | None = None):
        cur = self.db.execute("UPDATE positions SET status='closed', closed_ts=? WHERE id=? AND status IN (?,?)",
                              (time.time() if now is None else now, pid, *OPEN_STATES))
        self.db.commit()
        if cur.rowcount == 0:
            raise KeyError("posição inexistente ou já fechada")

    # ---------------------------------------------------------------- watchlists
    @classmethod
    def normalize_symbol(cls, symbol: str) -> str:
        sym = (symbol or "").strip().upper()
        if not cls.SYMBOL_RE.match(sym):
            raise ValueError(f"símbolo inválido: {symbol!r}")
        return sym

    def create_watchlist(self, name: str) -> int:
        name = (name or "").strip()
        if not name or len(name) > 60:
            raise ValueError("nome inválido (1 a 60 caracteres)")
        try:
            cur = self.db.execute("INSERT INTO watchlists(name) VALUES(?)", (name,))
        except sqlite3.IntegrityError:
            raise ValueError("já existe uma lista com esse nome") from None
        self.db.commit()
        return cur.lastrowid

    def delete_watchlist(self, wid: int) -> bool:
        cur = self.db.execute("DELETE FROM watchlists WHERE id=?", (wid,))
        self.db.commit()
        return cur.rowcount > 0

    def add_symbol(self, wid: int, symbol: str) -> str:
        sym = self.normalize_symbol(symbol)
        if not self.db.execute("SELECT 1 FROM watchlists WHERE id=?", (wid,)).fetchone():
            raise KeyError("lista inexistente")
        self.db.execute("INSERT OR IGNORE INTO watchlist_symbols VALUES(?,?)", (wid, sym))
        self.db.commit()
        return sym

    def remove_symbol(self, wid: int, symbol: str) -> bool:
        cur = self.db.execute("DELETE FROM watchlist_symbols WHERE watchlist_id=? AND symbol=?",
                              (wid, symbol.strip().upper()))
        self.db.commit()
        return cur.rowcount > 0

    def list_watchlists(self) -> list[dict]:
        out = []
        for wid, name in self.db.execute("SELECT id,name FROM watchlists ORDER BY name").fetchall():
            syms = [r[0] for r in self.db.execute(
                "SELECT symbol FROM watchlist_symbols WHERE watchlist_id=? ORDER BY symbol", (wid,))]
            out.append({"id": wid, "name": name, "symbols": syms})
        return out

    def all_symbols(self) -> list[str]:
        return [r[0] for r in self.db.execute("SELECT DISTINCT symbol FROM watchlist_symbols ORDER BY symbol")]
