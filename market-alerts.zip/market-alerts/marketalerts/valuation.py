"""Valorização relativa baseada só em preço (posição no intervalo de 52 semanas e
distância à média de 200 dias). NÃO é valorização fundamental (P/E, DCF, preço-alvo)."""
from __future__ import annotations
from .models import Bar


def valuation(bars: list[Bar], cheap_pos: float = 0.35, expensive_pos: float = 0.80,
              lookback: int = 252, min_bars: int = 120) -> dict | None:
    if len(bars) < min_bars:
        return None
    w = bars[-lookback:]
    hi, lo = max(b.high for b in w), min(b.low for b in w)
    if hi <= lo:
        return None
    last = bars[-1].close
    pos = min(1.0, max(0.0, (last - lo) / (hi - lo)))
    label = "barato" if pos <= cheap_pos else "caro" if pos >= expensive_pos else "neutro"
    vs200 = None
    if len(bars) >= 200:
        sma200 = sum(b.close for b in bars[-200:]) / 200
        vs200 = (last / sma200 - 1) * 100
    text = f"{label} face ao último ano: {pos * 100:.0f}% do intervalo de 52 semanas ({lo:.2f} a {hi:.2f})"
    if vs200 is not None:
        text += f"; {vs200:+.1f}% vs média de 200 dias"
    return {"label": label, "pos52": pos, "lo": lo, "hi": hi, "vs200_pct": vs200, "text": text}
