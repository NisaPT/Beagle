"""Indicadores em Python puro (sem dependências), para serem fáceis de testar."""
from __future__ import annotations
from math import sqrt
from .models import Bar


def sma(values: list[float], n: int) -> float:
    if len(values) < n:
        raise ValueError(f"precisa de {n} valores, tem {len(values)}")
    return sum(values[-n:]) / n


def zscore(values: list[float], n: int) -> float:
    """Distância do último valor à média das últimas n, em desvios-padrão."""
    if len(values) < n:
        raise ValueError(f"precisa de {n} valores, tem {len(values)}")
    w = values[-n:]
    m = sum(w) / n
    sd = sqrt(sum((x - m) ** 2 for x in w) / n)
    return 0.0 if sd == 0 else (values[-1] - m) / sd


def rsi(closes: list[float], n: int = 14) -> float:
    """RSI de Wilder."""
    if len(closes) < n + 1:
        raise ValueError(f"precisa de {n + 1} fechos, tem {len(closes)}")
    gains = losses = 0.0
    for i in range(1, n + 1):
        d = closes[i] - closes[i - 1]
        gains += max(d, 0)
        losses += max(-d, 0)
    avg_g, avg_l = gains / n, losses / n
    for i in range(n + 1, len(closes)):
        d = closes[i] - closes[i - 1]
        avg_g = (avg_g * (n - 1) + max(d, 0)) / n
        avg_l = (avg_l * (n - 1) + max(-d, 0)) / n
    if avg_l == 0:
        return 100.0 if avg_g > 0 else 50.0
    rs = avg_g / avg_l
    return 100 - 100 / (1 + rs)


def atr(bars: list[Bar], n: int = 14) -> float:
    """Average True Range de Wilder."""
    if len(bars) < n + 1:
        raise ValueError(f"precisa de {n + 1} barras, tem {len(bars)}")
    trs = []
    for i in range(1, len(bars)):
        b, p = bars[i], bars[i - 1]
        trs.append(max(b.high - b.low, abs(b.high - p.close), abs(b.low - p.close)))
    a = sum(trs[:n]) / n
    for tr in trs[n:]:
        a = (a * (n - 1) + tr) / n
    return a
