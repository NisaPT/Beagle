"""Interface web local para gerir watchlists. Só escuta em 127.0.0.1 (sem autenticação)."""
from __future__ import annotations
import argparse, json, re
from http.server import BaseHTTPRequestHandler, HTTPServer
from .store import Store

PAGE = """<!doctype html><html lang="pt"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Alertas de mercado</title>
<style>
body{font:16px/1.5 system-ui,sans-serif;max-width:760px;margin:0 auto;padding:16px;color:#1a1a1a}
h1{font-size:1.4rem} h2{font-size:1.1rem;margin-top:28px}
.card{border:1px solid #d0d0d0;border-radius:8px;padding:12px;margin:12px 0}
.card.buy{border-left:6px solid #15803d} .card.sell{border-left:6px solid #b91c1c;background:#fef2f2}
.row{display:flex;gap:8px;flex-wrap:wrap;align-items:center;justify-content:space-between}
.badge{font-size:.8rem;border:1px solid #15803d;color:#15803d;border-radius:999px;padding:1px 8px}
.muted{color:#555;font-size:.9rem} .pos{color:#15803d} .neg{color:#b91c1c}
form{display:flex;gap:8px;flex-wrap:wrap;align-items:end} label{display:flex;flex-direction:column;font-size:.85rem;gap:2px}
input{padding:8px;border:1px solid #888;border-radius:6px;font-size:1rem}
button{padding:8px 12px;border-radius:6px;border:1px solid #333;background:#fff;cursor:pointer;min-height:40px}
button.primary{background:#1a1a1a;color:#fff} :focus-visible{outline:3px solid #2563eb;outline-offset:2px}
.chip{display:inline-flex;gap:6px;align-items:center;border:1px solid #bbb;border-radius:999px;padding:2px 4px 2px 10px;margin:2px}
.chip button{border:0;min-height:28px;padding:2px 8px} #msg{color:#b00020;min-height:1.5em} .empty{color:#555}
</style></head><body>
<h1>Alertas de mercado</h1><p id="msg" role="alert"></p>
<h2>Alertas de compra <span id="pcount" class="muted"></span></h2><div id="alerts"></div>
<h2>Em monitorização (aguardam sinal de venda)</h2><div id="positions"></div>
<h2>As minhas watchlists</h2>
<form id="new"><label>Nome da lista<input id="name" maxlength="60" required></label>
<button class="primary" type="submit">Criar lista</button></form><div id="lists"></div>
<script>
const $=s=>document.querySelector(s), msg=t=>$('#msg').textContent=t||'';
async function api(path,method='GET',body){
  const r=await fetch(path,{method,headers:{'Content-Type':'application/json'},body:body?JSON.stringify(body):undefined});
  const j=await r.json().catch(()=>({})); if(!r.ok) throw new Error(j.error||'Erro'); return j;}
function el(t,props={},...kids){const e=document.createElement(t);Object.assign(e,props);kids.forEach(k=>e.append(k));return e;}
function ago(ts){const s=Math.max(0,Math.floor(Date.now()/1000-ts));
  if(s<60)return 'há '+s+' s'; if(s<3600)return 'há '+Math.floor(s/60)+' min';
  if(s<86400)return 'há '+Math.floor(s/3600)+' h '+Math.floor(s%3600/60)+' min'; return 'há '+Math.floor(s/86400)+' d';}
const when=ts=>el('span',{className:'muted',textContent:ago(ts),title:new Date(ts*1000).toLocaleString('pt-PT')});
const f2=x=>x==null?'-':Number(x).toFixed(2);

async function renderAlerts(){
  const data=await api('/api/alerts'), box=$('#alerts'); box.replaceChildren();
  $('#pcount').textContent=data.length?'('+data.length+')':''; document.title=(data.length?'('+data.length+') ':'')+'Alertas de mercado';
  if(!data.length){box.append(el('p',{className:'empty',textContent:'Sem alertas de compra neste momento.'}));return;}
  for(const a of data){
    const card=el('div',{className:'card buy'});
    card.append(el('div',{className:'row'},el('strong',{textContent:a.symbol+' · possível compra a '+f2(a.price)}),
      el('span',{className:'badge',textContent:'Qualidade '+a.score+'/'+a.max_score})));
    card.append(el('p',{textContent:a.reason}));
    if(a.valuation) card.append(el('p',{className:'muted',textContent:'Valorização: '+a.valuation}));
    card.append(el('p',{className:'muted',textContent:'Stop-loss sugerido '+f2(a.stop)+' (risco '+f2(a.risk_pct)+'%) · Alvo '+f2(a.target)}));
    card.append(el('div',{className:'row'},el('span',{},'Emitido ',when(a.ts)),
      el('span',{},el('button',{className:'primary',textContent:'Aplicar',onclick:()=>act(()=>api('/api/alerts/'+a.id+'/apply','POST'))}),' ',
      el('button',{textContent:'Rejeitar',onclick:()=>act(()=>api('/api/alerts/'+a.id+'/reject','POST'))}))));
    box.append(card);}
}
async function renderPositions(){
  const data=await api('/api/positions'), box=$('#positions'); box.replaceChildren();
  if(!data.length){box.append(el('p',{className:'empty',textContent:'Sem posições em monitorização. Quando aplicares um alerta de compra, aparece aqui.'}));return;}
  for(const p of data){
    const pl=p.entry?(p.last_price/p.entry-1)*100:0, sig=p.status==='sell_signal';
    const card=el('div',{className:'card'+(sig?' sell':'')});
    card.append(el('div',{className:'row'},el('strong',{textContent:p.symbol}),
      el('span',{className:pl>=0?'pos':'neg',textContent:(pl>=0?'+':'')+pl.toFixed(2)+'%'})));
    card.append(el('p',{className:'muted',textContent:'Entrada '+f2(p.entry)+' · Último '+f2(p.last_price)+' · Stop '+f2(p.stop)+' · Alvo '+f2(p.target)}));
    card.append(el('div',{},'Aplicado ',when(p.applied_ts)));
    if(sig){card.append(el('p',{},el('strong',{textContent:'Sinal de venda: '}),p.sell_reason+' ',when(p.sell_ts)));
      card.append(el('button',{className:'primary',textContent:'Marcar como vendida',onclick:()=>act(()=>api('/api/positions/'+p.id+'/close','POST'))}));}
    else card.append(el('p',{className:'muted',textContent:'À espera do alerta de venda.'}));
    box.append(card);}
}
async function renderLists(){
  const data=await api('/api/watchlists'), box=$('#lists'); box.replaceChildren();
  if(!data.length){box.append(el('p',{className:'empty',textContent:'Ainda não tens listas. Cria a primeira acima.'}));return;}
  for(const w of data){
    const card=el('div',{className:'card'});
    const head=el('div',{},el('strong',{textContent:w.name+' '}),
      el('button',{textContent:'Eliminar lista',onclick:()=>act(()=>api('/api/watchlists/'+w.id,'DELETE'))}));
    const chips=el('div');
    if(!w.symbols.length) chips.append(el('span',{className:'empty',textContent:'Lista vazia. Adiciona um símbolo.'}));
    for(const s of w.symbols) chips.append(el('span',{className:'chip'},s,
      el('button',{textContent:'Remover',ariaLabel:'Remover '+s,onclick:()=>act(()=>api('/api/watchlists/'+w.id+'/symbols/'+encodeURIComponent(s),'DELETE'))})));
    const f=el('form'),inp=el('input',{maxLength:15,required:true,placeholder:'ex.: AAPL, SPY, BTC-USD'});
    f.append(el('label',{},'Símbolo',inp),el('button',{className:'primary',type:'submit',textContent:'Adicionar símbolo'}));
    f.onsubmit=e=>{e.preventDefault();act(()=>api('/api/watchlists/'+w.id+'/symbols','POST',{symbol:inp.value}));};
    card.append(head,chips,f);box.append(card);}
}
async function refresh(){await Promise.all([renderAlerts(),renderPositions()]);}
async function act(fn){try{msg('');await fn();await Promise.all([refresh(),renderLists()]);}catch(e){msg(e.message);}}
$('#new').onsubmit=e=>{e.preventDefault();act(async()=>{await api('/api/watchlists','POST',{name:$('#name').value});$('#name').value='';});};
refresh().catch(e=>msg(e.message)); renderLists().catch(e=>msg(e.message));
setInterval(()=>refresh().catch(()=>{}),15000);
</script></body></html>"""


def make_handler(store: Store):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):  # silencioso
            pass

        def _send(self, code, payload, ctype="application/json"):
            body = payload if isinstance(payload, bytes) else json.dumps(payload).encode()
            self.send_response(code)
            self.send_header("Content-Type", ctype + "; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(body)

        def _json(self):
            n = int(self.headers.get("Content-Length") or 0)
            if n > 4096:
                raise ValueError("pedido demasiado grande")
            try:
                data = json.loads(self.rfile.read(n) or b"{}")
            except json.JSONDecodeError:
                raise ValueError("JSON inválido") from None
            if not isinstance(data, dict):
                raise ValueError("JSON inválido")
            return data

        def _guard(self, fn):
            try:
                code, out = fn()
            except ValueError as e:
                code, out = 400, {"error": str(e)}
            except KeyError as e:
                code, out = 404, {"error": e.args[0] if e.args else "não encontrado"}
            self._send(code, out)

        def do_GET(self):
            if self.path == "/":
                return self._send(200, PAGE.encode(), "text/html")
            if self.path == "/api/watchlists":
                return self._send(200, store.list_watchlists())
            if self.path == "/api/alerts":
                return self._send(200, store.pending_alerts())
            if self.path == "/api/positions":
                return self._send(200, store.open_positions())
            self._send(404, {"error": "não encontrado"})

        def do_POST(self):
            def go():
                if self.path == "/api/watchlists":
                    d = self._json()
                    return 201, {"id": store.create_watchlist(d.get("name", ""))}
                m = re.fullmatch(r"/api/watchlists/(\d+)/symbols", self.path)
                if m:
                    return 201, {"symbol": store.add_symbol(int(m[1]), self._json().get("symbol", ""))}
                m = re.fullmatch(r"/api/alerts/(\d+)/(apply|reject)", self.path)
                if m:
                    if m[2] == "apply":
                        return 201, {"position_id": store.apply_alert(int(m[1]))}
                    store.reject_alert(int(m[1]))
                    return 200, {"ok": True}
                m = re.fullmatch(r"/api/positions/(\d+)/close", self.path)
                if m:
                    store.close_position(int(m[1]))
                    return 200, {"ok": True}
                raise KeyError("não encontrado")
            self._guard(go)

        def do_DELETE(self):
            from urllib.parse import unquote

            def go():
                m = re.fullmatch(r"/api/watchlists/(\d+)", self.path)
                if m:
                    if not store.delete_watchlist(int(m[1])):
                        raise KeyError("lista inexistente")
                    return 200, {"ok": True}
                m = re.fullmatch(r"/api/watchlists/(\d+)/symbols/([^/]+)", self.path)
                if m:
                    if not store.remove_symbol(int(m[1]), unquote(m[2])):
                        raise KeyError("símbolo inexistente")
                    return 200, {"ok": True}
                raise KeyError("não encontrado")
            self._guard(go)
    return H


def serve(store: Store, port: int = 8000) -> HTTPServer:
    return HTTPServer(("127.0.0.1", port), make_handler(store))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default="alerts.db")
    ap.add_argument("--port", type=int, default=8000)
    a = ap.parse_args()
    print(f"A servir em http://127.0.0.1:{a.port}")
    serve(Store(a.db), a.port).serve_forever()
